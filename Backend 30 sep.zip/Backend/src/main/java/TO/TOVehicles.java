package TO;

import java.util.Date;
import java.util.*;
public class TOVehicles{
    
    private int idVehicles; 
    private String placa; 
    private String tipoVehiculo; 
    private Date horaEntrada;
    private Date horaSalida;
    private Double valorMinuto; 
    private Double valorPagar;
    private TOUsers usuario;
    private TOPlazasNeway plaza;
    
    private int idPlazaVehiculo; 
    private int idUsuarioVehiculo;
    
    private String tipoPlaza;
    private String codigoPlaza;
    private String estadoPlaza;

    public TOVehicles() {
    }
    

    public int getIdVehicles() {
        return idVehicles;
    }

    public void setIdVehicles(int idVehicles) {
        this.idVehicles = idVehicles;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

    public Date getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(Date horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public Date getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Date horaSalida) {
        this.horaSalida = horaSalida;
    }

    public Double getValorMinuto() {
        return valorMinuto;
    }

    public void setValorMinuto(Double valorMinuto) {
        this.valorMinuto = valorMinuto;
    }

    public Double getValorPagar() {
        return valorPagar;
    }

    public void setValorPagar(Double valorPagar) {
        this.valorPagar = valorPagar;
    }

    public int getIdPlazaVehiculo() {
        return idPlazaVehiculo;
    }

    public void setIdPlazaVehiculo(int idPlazaVehiculo) {
        this.idPlazaVehiculo = idPlazaVehiculo;
    }

    public int getIdUsuarioVehiculo() {
        return idUsuarioVehiculo;
    }

    public void setIdUsuarioVehiculo(int idUsuarioVehiculo) {
        this.idUsuarioVehiculo = idUsuarioVehiculo;
    }

    public String getTipoPlaza() {
        return tipoPlaza;
    }

    public void setTipoPlaza(String tipoPlaza) {
        this.tipoPlaza = tipoPlaza;
    }

    public String getCodigoPlaza() {
        return codigoPlaza;
    }

    public void setCodigoPlaza(String codigoPlaza) {
        this.codigoPlaza = codigoPlaza;
    }

    public String getEstadoPlaza() {
        return estadoPlaza;
    }

    public void setEstadoPlaza(String estadoPlaza) {
        this.estadoPlaza = estadoPlaza;
    }

    public TOUsers getUsuario() {
        return usuario;
    }

    public void setUsuario(TOUsers usuario) {
        this.usuario = usuario;
    }

    public TOPlazasNeway getPlaza() {
        return plaza;
    }

    public void setPlaza(TOPlazasNeway plaza) {
        this.plaza = plaza;
    }

    

    

    

    
    
}
