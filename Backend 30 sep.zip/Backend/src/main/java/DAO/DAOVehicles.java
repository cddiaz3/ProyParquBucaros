package DAO;

import TO.TOPlazasNeway;
import TO.TOUsers;
import TO.TOVehicles;
import db.ConexionDB;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOVehicles {

    private final ConexionDB con;
    private final String nombreTabla;
    private final String nombreVista;

    public DAOVehicles() {
        con = new ConexionDB();
        this.nombreTabla = "vehicles";
        this.nombreVista = "vistavehiculos";
    }

    public ArrayList<TOVehicles> consultarVehicles() {
        TOVehicles vehicle;
        ArrayList<TOVehicles> vehicles = new ArrayList<>();
        try {
            ResultSet rs = con.consultar(nombreVista);
            while (rs.next()) {
                vehicle = new TOVehicles();
                TOUsers usuario = new TOUsers();
                TOPlazasNeway plaza = new TOPlazasNeway();
                
                vehicle.setIdVehicles(rs.getInt("idVehicles"));
                vehicle.setPlaca(rs.getString("placa"));
                vehicle.setTipoVehiculo(rs.getString("tipoVehiculo"));
                vehicle.setHoraEntrada(rs.getDate("horaEntrada"));
                vehicle.setHoraSalida(rs.getDate("horaSalida"));
                vehicle.setValorMinuto(rs.getDouble("valorMinuto"));
                vehicle.setValorPagar(rs.getDouble("valorPagar"));
                vehicle.setIdPlazaVehiculo(rs.getInt("idPlazaVehiculo"));
                vehicle.setIdUsuarioVehiculo(rs.getInt("idUsuarioVehiculo"));
                
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                usuario.setName(rs.getString("name"));
                usuario.setLastname(rs.getString("lastname"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTipoDocumento(rs.getString("tipoDocumento"));
                usuario.setDocumento(rs.getString("documento"));
                usuario.setCellphone(rs.getString("cellphone"));
                
                
                plaza.setTipoPlaza(rs.getString("tipoPlaza"));
                plaza.setCodigoPlaza(rs.getString("codigoPlaza"));
                plaza.setEstadoPlaza(rs.getString("estadoPlaza"));
                                

                vehicles.add(vehicle);
            }
            return vehicles;
        } catch (SQLException ex) {
            System.out.println("Error en DAO Users.consultarVehicles: " + ex.getMessage());
            return null;
        }
    }

    public int insertarVehicles(TOVehicles vehicle) {
        String[] valores = {
            
            vehicle.getPlaca(),
            vehicle.getTipoVehiculo(),
            vehicle.getHoraEntrada().toString(),
            vehicle.getHoraSalida().toString(),
            vehicle.getValorMinuto().toString(),
            vehicle.getValorPagar().toString(),
            String.valueOf(vehicle.getIdPlazaVehiculo()),
            String.valueOf(vehicle.getIdUsuarioVehiculo()),
            
            vehicle.getUsuario().getUsername(),//hacer esto con todas los cambios
            vehicle.getUsuario().getPassword(), 
            vehicle.getUsuario().getName(), 
            vehicle.getUsuario().getLastname(), 
            vehicle.getUsuario().getEmail(),
            vehicle.getUsuario().getTipoDocumento(),
            vehicle.getUsuario().getDocumento(),
            vehicle.getUsuario().getCellphone(),
            
            vehicle.getPlaza().getTipoPlaza(),
            vehicle.getPlaza().getCodigoPlaza(),
            vehicle.getPlaza().getEstadoPlaza()};
        try {
            return con.insertar(nombreVista, valores);
        } catch (Exception ex) {
            System.out.println("Error en DAO Vehicles.insertarVehicles: " + ex.getMessage());
            return 0;
        }
    }

    public boolean modificarVehicles(TOVehicles vehicle) {
        String[] valores = {

            vehicle.getPlaca(),
            vehicle.getTipoVehiculo(),
            vehicle.getHoraEntrada().toString(),
            vehicle.getHoraSalida().toString(),
            vehicle.getValorMinuto().toString(),
            vehicle.getValorPagar().toString(),
            String.valueOf(vehicle.getIdPlazaVehiculo()),
            String.valueOf(vehicle.getIdUsuarioVehiculo()),
            
            vehicle.getUsuario().getUsername(), 
            vehicle.getUsuario().getPassword(), 
            vehicle.getUsuario().getName(), 
            vehicle.getUsuario().getLastname(), 
            vehicle.getUsuario().getEmail(),
            vehicle.getUsuario().getTipoDocumento(),
            vehicle.getUsuario().getDocumento(),
            vehicle.getUsuario().getCellphone(),
            
            vehicle.getPlaza().getTipoPlaza(),
            vehicle.getPlaza().getCodigoPlaza(),
            vehicle.getPlaza().getEstadoPlaza()};
        try {
            return con.actualizar(nombreVista, valores, vehicle.getIdVehicles());
        } catch (Exception ex) {
            System.out.println("Error en DAO Vehicles.modificarVehicles: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminarUVehicles(int id) {
        try {
            return con.eliminar(nombreVista, id);
        } catch (Exception ex) {
            System.out.println("Error en DAO Vehicles.eliminarVehicles: " + ex.getMessage());
            return false;
        }
    }

}
