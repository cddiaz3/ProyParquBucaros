package DAO;

import TO.TOPlazasNeway;
import db.ConexionDB;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOPlazasNeway {
    
    private final ConexionDB con;
    private final String nombreTabla;

    public DAOPlazasNeway() {
       con = new ConexionDB();
       this.nombreTabla = "plazasneway"; 
    }
    
    public ArrayList<TOPlazasNeway> consultarUsuarios() {
        TOPlazasNeway plazaneway;
        ArrayList<TOPlazasNeway> plazasneway = new ArrayList<>();
        try {
            ResultSet rs = con.consultar(nombreTabla);
            while (rs.next()) {

                plazaneway = new TOPlazasNeway();              
                
                plazaneway.setTipoPlaza(rs.getString("tipoPlaza"));
                plazaneway.setCodigoPlaza(rs.getString("codigoPlaza"));
                plazaneway.setEstadoPlaza(rs.getString("estadoPlaza"));

                plazasneway.add(plazaneway);
            }
            return plazasneway;
        } catch (SQLException ex) {
            System.out.println("Error en DAO PlazasNeway.consultarPlazasNeay: " + ex.getMessage());
            return null;
        }
    }

    public int insertarUsuarios(TOPlazasNeway plazaneway) {
        String[] valores = { 
            plazaneway.getTipoPlaza(),
            plazaneway.getCodigoPlaza(),
            plazaneway.getEstadoPlaza()};
        try {
            return con.insertar(nombreTabla, valores);
        } catch (Exception ex) {
            System.out.println("Error en DAO PlazasNeway.insertarPlazasNeay: " + ex.getMessage());
            return 0;
        }
    }
    
    public boolean modificarUsuarios(TOPlazasNeway plazaneway) {
        String[] valores = {
            plazaneway.getTipoPlaza(),
            plazaneway.getCodigoPlaza(),
            plazaneway.getEstadoPlaza()};
        try {
            return con.actualizar(nombreTabla, valores, plazaneway.getIdPlazasNeway());
        } catch (Exception ex) {
            System.out.println("Error en DAO PlazasNeway.modificarPlazasNeay: " + ex.getMessage());
            return false;
        }
    }
    
    public boolean eliminarUsuarios(int id) {
        try {
            return con.eliminar(nombreTabla, id);
        } catch (Exception ex) {
            System.out.println("Error en DAO PlazasNeway.eliminarPlazasNeay: " + ex.getMessage());
            return false;
        }
    }
    
}
