package DAO;

import TO.TOUsers;
import db.ConexionDB;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOUsers {

    private final ConexionDB con;
    private final String nombreTabla;

    public DAOUsers() {
        con = new ConexionDB();
        this.nombreTabla = "users";
    }

    public ArrayList<TOUsers> consultarUsuarios() {
        TOUsers user;
        ArrayList<TOUsers> users = new ArrayList<>();
        try {
            ResultSet rs = con.consultar(nombreTabla);
            while (rs.next()) {
                
                user = new TOUsers();
                
                user.setIdUsers(rs.getInt("idUsers"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setName(rs.getString("name"));
                user.setLastname(rs.getString("lastname"));
                user.setEmail(rs.getString("email"));
                user.setTipoDocumento(rs.getString("tipoDocumento"));
                user.setDocumento(rs.getString("documento"));
                user.setCellphone(rs.getString("cellphone"));  

                users.add(user);
            }
            return users;
        } catch (SQLException ex) {
            System.out.println("Error en DAO Users.consultarUsuarios: " + ex.getMessage());
            return null;
        }
    }

    public int insertarUsuarios(TOUsers user) {
        String[] valores = {user.getUsername(), user.getPassword(), user.getName(), user.getLastname(), user.getEmail(), user.getTipoDocumento(), user.getDocumento(), user.getCellphone()};
        try {
            return con.insertar(nombreTabla, valores);
        } catch (Exception ex) {
            System.out.println("Error en DAO Users.insetarrUsuarios: " + ex.getMessage());
            return 0;
        }
    }
    
    public boolean modificarUsuarios(TOUsers user) {
        String[] valores = {user.getUsername(), user.getPassword(), user.getName(), user.getLastname(), user.getEmail(), user.getTipoDocumento(), user.getDocumento(), user.getCellphone()};
        try {
            return con.actualizar(nombreTabla, valores, user.getIdUsers());
        } catch (Exception ex) {
            System.out.println("Error en DAO Users.modificarUsuarios: " + ex.getMessage());
            return false;
        }
    }
    
    public boolean eliminarUsuarios(int id) {
        try {
            return con.eliminar(nombreTabla, id);
        } catch (Exception ex) {
            System.out.println("Error en DAO Users.elimin   arUsuarios: " + ex.getMessage());
            return false;
        }
    }
}
