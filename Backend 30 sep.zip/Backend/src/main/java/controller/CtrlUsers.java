package controller;

import DAO.DAOUsers;
import TO.TOUsers;
import java.util.ArrayList;

public class CtrlUsers {

    DAOUsers usersDAO;

    public CtrlUsers() {
        usersDAO = new DAOUsers();
    }

    public ArrayList<TOUsers> consultarUsuarios() {
        return usersDAO.consultarUsuarios();
    }

    public int insertarUsuarios(TOUsers user) {
        return usersDAO.insertarUsuarios(user);
    }

    public boolean modificarUsuarios(TOUsers user) {
        return usersDAO.modificarUsuarios(user);
    }

    public boolean eliminarUsuarios(int id) {
        return usersDAO.eliminarUsuarios(id);
    }

}
