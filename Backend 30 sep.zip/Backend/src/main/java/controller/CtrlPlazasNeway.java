package controller;

import DAO.DAOPlazasNeway;
import TO.TOPlazasNeway;
import java.util.ArrayList;

public class CtrlPlazasNeway {

    DAOPlazasNeway plazasnewayDAO;
    
    public CtrlPlazasNeway() {
        plazasnewayDAO = new DAOPlazasNeway();
    }

        public CtrlPlazasNeway(DAOPlazasNeway plazasnewayDAO) {
        plazasnewayDAO = new DAOPlazasNeway();
    }

    public ArrayList<TOPlazasNeway> consultarUsuarios() {
        return plazasnewayDAO.consultarUsuarios();
    }

    public int insertarUsuarios(TOPlazasNeway plazaneway) {
        return plazasnewayDAO.insertarUsuarios(plazaneway);
    }

    public boolean modificarUsuarios(TOPlazasNeway plazaneway) {
        return plazasnewayDAO.modificarUsuarios(plazaneway);
    }

    public boolean eliminarUsuarios(int id) {
        return plazasnewayDAO.eliminarUsuarios(id);
    }

}
