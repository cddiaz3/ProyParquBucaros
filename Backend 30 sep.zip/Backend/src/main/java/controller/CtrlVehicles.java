package controller;

import DAO.DAOVehicles;
import TO.TOVehicles;
import java.util.ArrayList;

public class CtrlVehicles {
    
    DAOVehicles vehiclesDAO;
    CtrlPlazasNeway plazasNewayCtrl;
    
    public CtrlVehicles() {
        vehiclesDAO = new DAOVehicles();
    }
               
    public ArrayList<TOVehicles> consultarVehicles() {
        return vehiclesDAO.consultarVehicles();
    }    
    
    public int insertarVehicles(TOVehicles vehicle) {    
        plazasNewayCtrl = new CtrlPlazasNeway();
        return vehiclesDAO.insertarVehicles(vehicle);        
    }
    
    public boolean modificarVehicles(TOVehicles vehicle) {        
        return vehiclesDAO.modificarVehicles(vehicle);
    }
    
    public boolean eliminarVehicles(int id) {
        return vehiclesDAO.eliminarUVehicles(id);        
    }
    
}
